1)Extract all files from the zip folder, and run the .bat file.
2)Enter passphrase when prompted.
3)CSR and private key will be generated in the same folder.
4)Incase of self signed certificate request, The certificate will also be generated in the same folder.